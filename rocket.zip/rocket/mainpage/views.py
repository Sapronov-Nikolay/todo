from .models import Task
from django.shortcuts import render

def index(request):
    result = ""
    for t in Task.objects.all():
        result += t.description
    kateg = ""    
    #for a in Kategorii.objects.all():
    #    kateg += a.kategoriya    
    return render(
        request,
        "mainpage/index.html",
        {"Задачи": Task.objects.all(), "Категории": kateg} # Kонтекст передаваемых переменных

    )